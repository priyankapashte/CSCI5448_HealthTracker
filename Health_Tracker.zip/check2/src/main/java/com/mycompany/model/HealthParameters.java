package com.mycompany.model;

public class HealthParameters {

}
